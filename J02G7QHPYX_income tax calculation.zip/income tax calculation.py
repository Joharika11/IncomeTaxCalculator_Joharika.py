income_of_individual=int(input())

if(income_of_individual <=250000):
    tax1=0
    print("tax to be paid: NIL tax")
    
if(income_of_individual>=250001 and income_of_individual<=500000):
    tax2=((income_of_individual-250000)*5)/100
    print("tax to be paid: "+str(tax2))
tax2=((income_of_individual-250000)*5)/100

if(income_of_individual>500000 and income_of_individual<=750000):
    tax3=((income_of_individual-500000)*10)/100
    tax=tax2+tax3
    print("tax to be paid: "+str(tax))
tax3=((income_of_individual-500000)*10)/100

if(income_of_individual>750000 and income_of_individual<=1000000):
    tax4=((income_of_individual-750000)*15)/100
    tax=tax2+tax3+tax4
    print("tax to be paid: "+str(tax))
tax4=((income_of_individual-750000)*15)/100

if(income_of_individual>1000000 and income_of_individual<=1250000):
    tax5=((income_of_individual-1000000)*20)/100
    tax=tax2+tax3+tax4+tax5
    print("tax to be paid: "+str(tax))
tax5=((income_of_individual-1000000)*20)/100

if(income_of_individual>1250000):
    tax6=((income_of_individual-1250000)*30)/100
    tax=tax2+tax3+tax4+tax5+tax6
    print("tax to be paid: "+str(tax))